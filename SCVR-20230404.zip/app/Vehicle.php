<?php

namespace App;

use App\Maintenance;
use App\VehicleType;
use Spatie\Activitylog\LogOptions;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Vehicle extends Model
{
    use HasFactory, LogsActivity;
    protected $fillable = [
        'picture',
        'vehicle_type_id',
        'reg_plate_number',
        'model',
        'make',
        'vin',
        'mileage',
        'purchase_date',
        'purchase_price',
        'seller_name',
        'seller_address',
        'seller_contact_number'
    ];

    public function vehicle_type(){
        return $this->belongsTo(VehicleType::class);
    }

    public function maintenance(){
        return $this->hasMany(Maintenance::class);
    }

    public function insurance(){
        return $this->hasOne(Insurance::class, 'vehicle_id');
    }

    public function getActivitylogOptions(): LogOptions    {
        return LogOptions::defaults()
            ->logOnly(['id', 'name'])
            ->logUnguarded();
    }
}
